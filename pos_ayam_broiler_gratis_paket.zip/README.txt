POS AYAM BROILER GRATIS — PANDUAN SINGKAT

FILE:
- index.html: aplikasi utama
- manifest.json dan sw.js: dukungan instalasi PWA jika dipasang pada hosting HTTPS

CARA PAKAI CEPAT (offline/local):
1. Buka index.html dengan browser atau aplikasi pembuka HTML di Android.
2. Tambahkan produk pada menu Produk & Stok. Masukkan modal, harga jual, stok, satuan, dan barcode.
3. Pilih kasir di menu Kasir.
4. Scan barcode (browser/perangkat yang mendukung) atau masukkan barcode secara manual.
5. Untuk transaksi utang, pilih "Utang pelanggan", isi nama, masukkan pembayaran awal, lalu selesaikan transaksi.
6. Catat pembayaran utang dari menu Utang Pelanggan.
7. Laporan laba kotor tersedia di menu Laporan. Ekspor CSV untuk dibuka di spreadsheet.
8. Buat backup JSON rutin di Pengaturan.

CARA PASANG SEBAGAI APLIKASI DI ANDROID:
- Untuk opsi "Tambahkan ke layar utama" yang andal dan dukungan offline PWA, unggah isi folder ini ke hosting HTTPS statis. Hosting gratis bisa digunakan, tetapi perlu akun dan koneksi internet saat mengunggah.
- Buka URL HTTPS di Chrome Android > menu ⋮ > Tambahkan ke layar utama / Instal aplikasi.
- Service worker melakukan cache aset untuk penggunaan offline setelah aplikasi dibuka online sekali.
- Membuka file HTML langsung dari penyimpanan bisa digunakan untuk versi lokal, tetapi biasanya tidak bisa memasang PWA dan scan kamera mungkin tidak tersedia.

BATASAN:
- Data tersimpan lokal pada browser/perangkat. Tidak ada sinkronisasi antar HP.
- Nama kasir hanya label transaksi, bukan login/izin akses yang aman.
- QRIS dicatat sebagai metode pembayaran saja, bukan integrasi pembayaran.
- Laba yang ditampilkan adalah estimasi laba kotor (belum dikurangi biaya operasional, susut, pajak, dan biaya lain).
- Cetak struk memakai dialog cetak browser dan memerlukan dukungan pop-up/printer.
- Buat backup sebelum mengganti browser/perangkat atau membersihkan data.
